# 📦 Response Trace Webhook Validator for Railway

## ✅ 功能

本项目部署于 Railway 云端函数，自动验证 `response_trace` 字段格式是否合法：

- 是 JSON 对象
- 包含 `gpt_reply` 与 `fallback`
- 两者均为字符串
- 不允许多余键、嵌套结构、null、布尔值

## 🚀 快速部署步骤

1. 上传本项目至 GitHub 仓库
2. 登陆 [Railway](https://railway.app/)
3. 新建 Project → 部署 GitHub 仓库
4. 设置环境变量（如需）
5. Railway 分配公网 URL，即为 Webhook 接口地址

## 接口说明

- POST `/api/input`
- Request Body:
```json
{
  "response_trace": {
    "gpt_reply": "...",
    "fallback": "..."
  }
}
```
- 成功响应:
```json
{ "status": "valid" }
```
- 失败响应:
```json
{ "error": "原因" }
```