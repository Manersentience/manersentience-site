module.exports = function validateResponseTrace(data) {
  if (typeof data !== 'object' || Array.isArray(data) || data === null) {
    return { valid: false, reason: "response_trace must be a JSON object" };
  }

  const keys = Object.keys(data);
  if (!keys.includes('gpt_reply') || !keys.includes('fallback')) {
    return { valid: false, reason: "Missing required keys: gpt_reply and fallback" };
  }

  if (typeof data.gpt_reply !== 'string' || typeof data.fallback !== 'string') {
    return { valid: false, reason: "gpt_reply and fallback must be strings" };
  }

  if (keys.length > 2) {
    return { valid: false, reason: "Extra keys not allowed in response_trace" };
  }

  return { valid: true };
};