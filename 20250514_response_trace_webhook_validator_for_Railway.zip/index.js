const express = require('express');
const bodyParser = require('body-parser');
const validateResponseTrace = require('./validation');

const app = express();
app.use(bodyParser.json());

app.post('/api/input', (req, res) => {
  const { response_trace } = req.body;
  const validation = validateResponseTrace(response_trace);

  if (!validation.valid) {
    return res.status(400).json({ error: validation.reason });
  }

  res.status(200).json({ status: "valid" });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Webhook validator running on port ${port}`);
});